<?php include "baseurl.php"; ?>

<link rel="stylesheet" href="<?= base_url ?>bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?= base_url ?>bootstrap-icons/bootstrap-icons.css">

<div class="d-flex">

  <!-- ======================
         SIDEBAR KIRI
    ======================= -->
  <div class="bg-info text-white vh-100 p-3 shadow" style="width:230px">

    <h4 class="fw-bold mb-4">HearMe!</h4>

    <ul class="nav flex-column">

      <li class="nav-item mb-2">
        <a href="<?= base_url ?>admin" class="nav-link text-white">
          <i class="bi bi-speedometer2"></i> Dashboard
        </a>
      </li>

      <li class="nav-item mb-2">
        <a href="<?= base_url ?>admin/kelas"
          class="nav-link text-white <?= ($_SESSION['menu'] == "kelas") ? 'active fw-bold' : ''; ?>">
          <i class="bi bi-building"></i> Kelas
        </a>
      </li>

      <li class="nav-item mb-2">
        <a href="<?= base_url ?>admin/siswa"
          class="nav-link text-white <?= ($_SESSION['menu'] == "siswa") ? 'active fw-bold' : ''; ?>">
          <i class="bi bi-people"></i> Siswa
        </a>
      </li>

      <li class="nav-item mb-2">
        <a href="<?= base_url ?>admin/kategori"
          class="nav-link text-white <?= ($_SESSION['menu'] == "kategori") ? 'active fw-bold' : ''; ?>">
          <i class="bi bi-tags"></i> Kategori
        </a>  
        </li>

     
      <li class="nav-item mb-2">
        <a href="<?= base_url ?>admin/aspirasi"
          class="nav-link text-white <?= ($_SESSION['menu'] == "aspirasi") ? 'active fw-bold' : ''; ?>">
          <i class="bi bi-chat-dots"></i> Aspirasi
        </a>  
        </li>

     

      <li class="nav-item mt-4">
        <a href="<?= base_url ?>login/logout.php" class="btn btn-light w-100">
          Keluar
        </a>
      </li>

    </ul>
  </div>

  <!-- ======================
         KONTEN HALAMAN
    ======================= -->
  <div class="flex-fill p-4">