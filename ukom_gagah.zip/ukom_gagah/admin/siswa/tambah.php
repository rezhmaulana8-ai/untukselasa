<?php
include "../../includes/koneksi.php";

$nama = $_POST['nama'];
$nis = $_POST['nis'];
$email = $_POST['email'];
$id_kelas = $_POST['id_kelas'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

mysqli_query($koneksi,"
INSERT INTO tb_user (nama, nis, email, id_kelas, password, role)
VALUES ('$nama','$nis','$email','$id_kelas','$password','user')
");

header("location:index.php?msg=1");
