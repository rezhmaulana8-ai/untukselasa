<?php
session_start();
include "../includes/koneksi.php";

if (!isset($_SESSION['id_user'])) {
    header("Location: /ukom_gatahu/login.php");
    exit;
}

$id_user = $_SESSION['id_user'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Riwayat Aspirasi</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

<style>
body{
  background:#f1f3f4;
  font-family: system-ui, -apple-system, BlinkMacSystemFont;
}

.history-container{
  max-width:900px;
  margin:auto;
}

.history-card{
  background:#fff;
  border-radius:12px;
  padding:16px 20px;
  margin-bottom:12px;
  box-shadow:0 1px 3px rgba(0,0,0,.08);
}

.history-header{
  display:flex;
  justify-content:space-between;
  align-items:center;
  font-size:.9rem;
  color:#5f6368;
}

.history-body{
  margin-top:8px;
  font-size:1rem;
  color:#202124;
}

.lokasi{
  font-weight:600;
}

.badge-status{
  font-size:.75rem;
}
</style>
</head>

<body>

<div class="container py-4 history-container">

  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold">📜 Riwayat Aspirasi</h4>
   <a href="index.php" class="btn btn-sm btn-outline-secondary">
  ← Dashboard
</a>
  </div>

<?php
$q = mysqli_query($koneksi,"
  SELECT * FROM tb_aspirasi
  WHERE id_user='$id_user'
  ORDER BY created_at DESC
");

if(mysqli_num_rows($q) > 0){
while($d = mysqli_fetch_assoc($q)){

$warna =
  $d['status']=='menunggu' ? 'warning' :
  ($d['status']=='proses' ? 'primary' :
  ($d['status']=='selesai' ? 'success' :
  ($d['status']=='ditolak' ? 'danger' : 'secondary')));
?>

  <div class="history-card">
    <div class="history-header">
      <span><?= date('d M Y • H:i', strtotime($d['created_at'])) ?></span>
      <span class="badge bg-<?= $warna ?> badge-status">
        <?= ucfirst($d['status']) ?>
      </span>
    </div>

    <div class="history-body">
      <div class="lokasi mb-1">
        <i class="bi bi-geo-alt"></i> <?= htmlspecialchars($d['lokasi']) ?>
      </div>
      <div>
        <?= nl2br(htmlspecialchars($d['isi_aspirasi'])) ?>
      </div>

      <?php if($d['status']=='selesai'){ ?>
       <div class="mt-2">
  <a href="" 
   class="btn btn-sm btn-outline-success d-flex align-items-center gap-1">
   <i class="bi bi-chat-dots"></i>
   <span>Feedback</span>
</a>

</div>

      <?php } ?>
    </div>
  </div>

<?php
}
}else{
?>
  <div class="text-center text-muted mt-5">
    Belum ada aspirasi 😶
  </div>
<?php } ?>

</div>

</body>
</html>