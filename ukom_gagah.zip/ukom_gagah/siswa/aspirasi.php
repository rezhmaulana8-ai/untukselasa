<?php
session_start();
include "../includes/koneksi.php";

/* =====================
   Validasi Login
===================== */
if(!isset($_SESSION['id_user'])){
    header("Location: ../login/login.php");
    exit;
}

/* =====================
   Ambil Data Form
===================== */
$id_user    = $_SESSION['id_user'];
$id_kategori = $_POST['id_kategori'];
$lokasi     = $_POST['lokasi'];
$isi        = $_POST['isi_aspirasi'];

/* =====================
   Validasi Input
===================== */
if($id_kategori == "" || $lokasi == "" || $isi == ""){
    echo "<script>
        alert('Semua field wajib diisi!');
        window.history.back();
    </script>";
    exit;
}

/* =====================
   Insert ke tb_aspirasi
===================== */
$query = mysqli_query($koneksi, "
    INSERT INTO tb_aspirasi
    (id_user, id_kategori, lokasi, isi_aspirasi, status, created_at, updated_at)
    VALUES
    ('$id_user', '$id_kategori', '$lokasi', '$isi', 'menunggu', NOW(), NOW())
");

/* =====================
   Redirect
===================== */
if($query){
    echo "<script>
        alert('Aspirasi berhasil dikirim!');
        window.location.href='index.php';
    </script>";
}else{
    echo "<script>
        alert('Gagal mengirim aspirasi!');
        window.history.back();
    </script>";
}
?>
