<?php
session_start();
include "../includes/koneksi.php";
include "../includes/baseurl.php";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tentang - Aduin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body{
            background: linear-gradient(180deg, #0077b6, #0096c7, #48cae4);
            min-height:100vh;
        }
        .card{
            border-radius:15px;
        }
        footer{
            background:#0077b6;
            color:white;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow fixed-top">
    <div class="container-fluid px-4">
        <a href="index.php" class="navbar-brand fw-bold">Aduin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a href="../siswa/index.php" class="nav-link">Dashboard</a></li>
                <li class="nav-item"><a href="histori.php" class="nav-link">Histori</a></li>
                <li class="nav-item"><a href="tentang.php" class="nav-link active">Tentang</a></li>
                <li class="nav-item ms-2">
                    <a href="../login/logout.php" class="btn btn-danger">Keluar</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Content -->
<div class="container mt-5 pt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card shadow-lg">
                <div class="card-body p-4">
                    <h3 class="fw-bold text-center mb-3">Tentang Aduin</h3>
                    <p class="text-center text-muted">Platform Aspirasi Siswa Digital</p>

                    <hr>

                    <p style="text-align: justify;">
                        <b>Aduin</b> adalah sistem informasi aspirasi siswa yang dibuat untuk memudahkan siswa dalam menyampaikan
                        laporan, kritik, saran, dan aspirasi secara digital, cepat, dan aman.
                        Sistem ini bertujuan untuk menciptakan lingkungan sekolah yang lebih terbuka, transparan,
                        dan responsif terhadap kebutuhan siswa.
                    </p>

                    <div class="row mt-4">
                        <div class="col-md-4 text-center mb-3">
                            <i class="bi bi-megaphone fs-1 text-primary"></i>
                            <h6 class="fw-bold mt-2">Sampaikan Aspirasi</h6>
                            <p class="small text-muted">Laporkan masalah dengan mudah dan cepat.</p>
                        </div>
                        <div class="col-md-4 text-center mb-3">
                            <i class="bi bi-clock-history fs-1 text-primary"></i>
                            <h6 class="fw-bold mt-2">Pantau Status</h6>
                            <p class="small text-muted">Lihat progres aspirasi secara real-time.</p>
                        </div>
                        <div class="col-md-4 text-center mb-3">
                            <i class="bi bi-shield-check fs-1 text-primary"></i>
                            <h6 class="fw-bold mt-2">Aman & Tercatat</h6>
                            <p class="small text-muted">Semua data tersimpan dengan aman.</p>
                        </div>
                    </div>

                    <div class="alert alert-primary mt-4 text-center">
                        <i class="bi bi-info-circle"></i>
                        Sistem ini dibuat sebagai bagian dari <b>Proyek UKOM</b> (Uji Kompetensi Keahlian)
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="w-100 text-center py-3 mt-auto">
    <small>© <?php echo date('Y'); ?> Aduin. All Rights Reserved.</small>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
