<?php
session_start();
$_SESSION['menu'] = "dashboard";



if (!isset($_SESSION['role']) || $_SESSION['role'] != 'siswa') {
  
}

include "../includes/koneksi.php";
include "../includes/navbarSiswa.php";
$id_user = $_SESSION['id_user'];

/* =========================
   NOTIF FEEDBACK ADMIN
========================= */
$notif = mysqli_query($koneksi, "
SELECT a.id_aspirasi, COUNT(f.id_feedback) as total
FROM tb_feedback f
JOIN tb_aspirasi a ON f.id_aspirasi = a.id_aspirasi
WHERE a.id_user = '$id_user'
AND f.id_user != '$id_user'
AND f.is_read = 0
GROUP BY a.id_aspirasi
ORDER BY MAX(f.created_at) DESC
LIMIT 1
");

if(!$notif){
    die("SQL ERROR: " . mysqli_error($koneksi));
}

$dataNotif = mysqli_fetch_assoc($notif);





// hitung data aspirasi
$total = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tb_aspirasi WHERE id_user='$id_user'"));
$menunggu = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tb_aspirasi WHERE id_user='$id_user' AND status='menunggu'"));
$proses = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tb_aspirasi WHERE id_user='$id_user' AND status='proses'"));
$selesai = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tb_aspirasi WHERE id_user='$id_user' AND status='selesai'"));
$ditolak = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tb_aspirasi WHERE id_user='$id_user' AND status='ditolak'"));
?>

<!DOCTYPE html>
<html lang="id">
<head>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>


/* layout utama */
.main-content{
    margin-left:240px;
    padding:20px;
    transition:.3s;
}

/* responsive */
@media(max-width:768px){
    .main-content{
        margin-left:0;
        padding:15px;
    }
}
</style>

</head>
<body class="bg-light">
  <button class="btn btn-light d-md-none position-fixed top-0 start-0 m-2 shadow"
        data-bs-toggle="offcanvas" 
        data-bs-target="#sidebarSiswa">
    <i class="bi bi-list fs-4"></i>
</button>


  


<div class="container mt-5 pt-4">

  <!-- Header -->
    <h4 class="fw-bold">Halo, <?php echo $_SESSION['nama']; ?> 👋</h4> <hr>
  <div class="d-flex justify-content-between align-items-center mb-4">
    
    <div>
    <button 
  class="btn btn-lg btn-success d-flex align-items-center gap-2 shadow-sm"
  data-bs-toggle="modal" 
  data-bs-target="#modalTambah">

  <i class="bi bi-send-fill fs-5"></i>
  <span class="fw-semibold">Kirim Aspirasi</span>

</button>
    </div>
    
  </div>
<div class="card border-0 shadow-sm mt-4">
  <div class="card-body text-center py-5">

    <!-- Icon Ilustrasi -->
    <div class="mb-3">
      <i class="bi bi-send fs-1 text-success"></i>
    </div>

    <!-- Judul -->
    <h5 class="fw-bold">Sampaikan Aspirasi Kamu</h5>

    <!-- Deskripsi -->
    <p class="text-muted mb-4">
      Suaramu penting untuk perubahan yang lebih baik.  
      Laporkan masalah, saran, dan aspirasi dengan mudah dan aman.
    </p>

    <!-- Step Info -->
    <div class="row g-3 justify-content-center">

      <div class="col-md-3 col-6">
        <div class="border rounded p-3 h-100">
          <i class="bi bi-pencil-square fs-4 text-primary"></i>
          <p class="mb-0 small mt-2 fw-semibold">Tulis Aspirasi</p>
        </div>
      </div>

      <div class="col-md-3 col-6">
        <div class="border rounded p-3 h-100">
          <i class="bi bi-send-check fs-4 text-success"></i>
          <p class="mb-0 small mt-2 fw-semibold">Kirim</p>
        </div>
      </div>

      <div class="col-md-3 col-6">
        <div class="border rounded p-3 h-100">
          <i class="bi bi-gear fs-4 text-warning"></i>
          <p class="mb-0 small mt-2 fw-semibold">Diproses Admin</p>
        </div>
      </div>

      <div class="col-md-3 col-6">
        <div class="border rounded p-3 h-100">
          <i class="bi bi-check-circle fs-4 text-success"></i>
          <p class="mb-0 small mt-2 fw-semibold">Selesai</p>
        </div>
      </div>

    </div>

  </div>
</div>

  <!-- Statistik -->
  <div class="row g-3 mt-3">

    <div class="col-md-3">
      <div class="card shadow text-center">
        <div class="card-body">
          <h6>Total Aspirasi</h6>
          <h2 class="fw-bold"><?php echo $total['total']; ?></h2>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card shadow text-center border-warning">
        <div class="card-body">
          <h6>Menunggu</h6>
          <h2 class="fw-bold text-warning"><?php echo $menunggu['total']; ?></h2>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card shadow text-center border-primary">
        <div class="card-body">
          <h6>Diproses</h6>
          <h2 class="fw-bold text-primary"><?php echo $proses['total']; ?></h2>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card shadow text-center border-success">
        <div class="card-body">
          <h6>Selesai</h6>
          <h2 class="fw-bold text-success"><?php echo $selesai['total']; ?></h2>
        </div>
      </div>
    </div>

     <div class="col-md-3">
      <div class="card shadow text-center border-danger">
        <div class="card-body">
          <h6>ditolak</h6>
          <h2 class="fw-bold text-danger"><?php echo $ditolak['total']; ?></h2>
        </div>
      </div>
      
    </div>

  </div>

  <!-- Aspirasi Terbaru -->
 <!-- ================= MENU NAVIGASI ================= -->
<div class="row g-3 mt-4 mb-4">

  <!-- Histori Aspirasi -->
  <div class="col-md-6">
    <div class="card border-0 shadow-sm h-100 hover-card">
      <div class="card-body d-flex align-items-center gap-3">

        <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center"
             style="width:60px;height:60px;">
          <i class="bi bi-clock-history fs-3"></i>
        </div>

        <div class="flex-grow-1">
          <h5 class="fw-bold mb-1">Histori Aspirasi</h5>
          <p class="mb-2 text-muted small">
            Lihat seluruh riwayat aspirasi yang pernah kamu kirim
          </p>
          <a href="histori.php" class="btn btn-outline-primary btn-sm">
            <i class="bi bi-arrow-right-circle"></i> Buka Histori
          </a>
        </div>

      </div>
    </div>
  </div>

  <!-- Feedback Aspirasi -->
  <?php if($dataNotif){ ?>
    <!-- ADA FEEDBACK BARU -->
    <a href="feedback.php?id=<?= $dataNotif['id_aspirasi'] ?>" 
       class="btn btn-success btn-sm position-relative">
      <i class="bi bi-chat-dots"></i> Buka Chat
      <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
        <?= $dataNotif['total'] ?>
      </span>
    </a>
<?php } else { ?>
    <!-- TIDAK ADA FEEDBACK -->
    <a href="histori.php" class="btn btn-outline-success btn-sm">
      <i class="bi bi-arrow-right-circle"></i> Lihat Histori
    </a>
<?php } ?>
>

</div>

    
<!-- ================= MODAL TAMBAH ASPIRASI ================= -->
<div class="modal fade" id="modalTambah" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <form method="POST" action="aspirasi.php">
        <div class="modal-header">
          <h5 class="modal-title fw-bold">Tambah Aspirasi</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">

          <!-- Kategori -->
          <div class="mb-3">
            <label class="form-label">Kategori</label>
            <select name="id_kategori" class="form-select" required>
              <option value="">-- Pilih Kategori --</option>
              <?php
              $qkat = mysqli_query($koneksi, "SELECT * FROM tb_kategori ORDER BY nama_kategori ASC");
              while($k = mysqli_fetch_assoc($qkat)){
              ?>
                <option value="<?php echo $k['id_kategori']; ?>">
                  <?php echo $k['nama_kategori']; ?>
                </option>
              <?php } ?>
            </select>
          </div>

          <!-- Lokasi -->
          <div class="mb-3">
            <label class="form-label">Lokasi</label>
            <input type="text" name="lokasi" class="form-control" 
                   placeholder="Contoh: Ruang Lab Komputer" required>
          </div>

          <!-- Isi Aspirasi -->
          <div class="mb-3">
            <label class="form-label">Isi Aspirasi</label>
            <textarea name="isi_aspirasi" class="form-control" rows="4" 
                      placeholder="Tulis aspirasi kamu..." required></textarea>
          </div>

        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-primary">
            <i class="bi bi-send"></i> Kirim Aspirasi
          </button>
        </div>
      </form>

    </div>
  </div>
</div>
</div>

  <!-- ISI DASHBOARD KAMU -->



</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</html>
<?php
include "../includes/footer.php";
?>