<?php
include "../../includes/koneksi.php";

$nama          = $_POST['nama'];
$nis           = $_POST['nis'];
$email         = $_POST['email'];
$jenis_kelamin = $_POST['jenis_kelamin'];   // ⬅️ TAMBAHAN
$id_kelas      = $_POST['id_kelas'];

// MD5 PASSWORD
$password = md5($_POST['password']);

$sql = "INSERT INTO tb_user (nama, nis, email, jenis_kelamin, id_kelas, password, role)
        VALUES ('$nama','$nis','$email','$jenis_kelamin','$id_kelas','$password','user')";

$query = mysqli_query($koneksi, $sql);

if(!$query){
    echo "SQL ERROR: " . mysqli_error($koneksi);
    die;
}

header("location:index.php?msg=1");
?>
