<?php
session_start();

/* =========================
   CEK ROLE ADMIN
========================= */
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("location:../../index.php");
    exit;
}

$_SESSION['menu'] = "aspirasi";

include "../../includes/koneksi.php";
include "../../includes/navbarAdmin.php";
?>

<main class="flex-fill">
<div class="container mt-4">

<h3 class="mb-3">Manajemen Aspirasi Siswa</h3>

<div class="table-responsive">
<table class="table table-bordered table-striped">

<thead class="table-info text-center">
<tr>
<th>No</th>
<th>Nama Siswa</th>
<th>Kategori</th>
<th>Lokasi</th>
<th>Aspirasi</th>

<th>Status</th>
<th>Tanggal</th>
<th width="120">Aksi</th>
</tr>
</thead>

<tbody>

<?php
$no=1;

$query = mysqli_query($koneksi,"
SELECT a.*, u.nama, k.nama_kategori
FROM tb_aspirasi a
JOIN tb_user u ON a.id_user=u.id_user
JOIN tb_kategori k ON a.id_kategori=k.id_kategori
ORDER BY a.created_at DESC
");

while($d = mysqli_fetch_array($query)){
?>

<tr>
<td class="text-center"><?= $no++ ?></td>
<td><?= $d['nama'] ?></td>
<td><?= $d['nama_kategori'] ?></td>
<td><?= $d['lokasi'] ?></td>
<td width="250"><?= $d['isi_aspirasi'] ?></td>

<!-- FOTO -->


<!-- STATUS -->
<td>
<form action="update_status.php" method="POST">
<input type="hidden" name="id" value="<?= $d['id_aspirasi'] ?>">

<select name="status" class="form-select form-select-sm"
        onchange="this.form.submit()">

<option value="menunggu" <?= $d['status']=="menunggu"?"selected":"" ?>>Menunggu</option>
<option value="proses" <?= $d['status']=="proses"?"selected":"" ?>>Proses</option>
<option value="selesai" <?= $d['status']=="selesai"?"selected":"" ?>>Selesai</option>
<option value="ditolak" <?= $d['status']=="ditolak"?"selected":"" ?>>ditolak</option>

</select>
</form>
</td>

<td><?= date('d-m-Y H:i', strtotime($d['created_at'])) ?></td>

<td class="text-center d-flex flex-column gap-1">

<?php if($d['status'] == 'proses'){ ?>
    <!-- TOMBOL FEEDBACK -->
    <a href="../../siswa/feedback.php?id=<?= $d['id_aspirasi'] ?>" 
       class="btn btn-success btn-sm d-flex align-items-center justify-content-center gap-1">
       <i class="bi bi-chat-dots"></i>
       Chat
    </a>
<?php } ?>

    <!-- TOMBOL HAPUS -->
    <a href="hapus.php?id=<?= $d['id_aspirasi'] ?>"
       onclick="return confirm('Hapus aspirasi ini?')"
       class="btn btn-danger btn-sm">
       Hapus
    </a>

</td>


</tr>

<?php } ?>

</tbody>
</table>
</div>

</div>
</main>
<script src="<?= base_url ?>bootstrap/js/bootstrap.bundle.min.js"></script>

