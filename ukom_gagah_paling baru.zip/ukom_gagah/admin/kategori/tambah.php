<?php
include "../../includes/koneksi.php";

$nama = $_POST['nama'];

mysqli_query($koneksi,"INSERT INTO tb_kategori (nama_kategori) VALUES ('$nama')");

header("location:index.php?msg=1");
?>