<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("location:../../index.php");
    exit;
}

$_SESSION['menu'] = "kategori";

include "../../includes/koneksi.php";
include "../../includes/navbarAdmin.php";
?>

<main class="flex-fill">
<div class="container mt-4">

<h2 class="mb-3">Manajemen Kategori</h2>

<!-- NOTIFIKASI -->
<?php if(isset($_GET['msg'])): ?>
<div id="notif" class="alert alert-success">Data berhasil diproses</div>

<script>
setTimeout(()=>{
    document.getElementById('notif').remove();
    window.history.replaceState(null,null,window.location.pathname);
},2000);
</script>
<?php endif; ?>


<!-- TOMBOL TAMBAH -->
<button class="btn btn-primary mb-3"
data-bs-toggle="modal"
data-bs-target="#tambah">
+ Tambah Kategori
</button>


<div class="table-responsive">
<table class="table table-bordered table-striped">

<thead class="table-info text-center">
<tr>
    <th width="50">No</th>
    <th>Nama Kategori</th>
    <th width="170">Aksi</th>
</tr>
</thead>

<tbody>

<?php
$no = 1;
$q = mysqli_query($koneksi,"SELECT * FROM tb_kategori ORDER BY nama_kategori ASC");

while($d = mysqli_fetch_array($q)){
?>

<tr>
<td class="text-center"><?= $no++; ?></td>
<td><?= $d['nama_kategori']; ?></td>

<td class="text-center">

<button class="btn btn-warning btn-sm"
data-bs-toggle="modal"
data-bs-target="#ubah<?= $d['id_kategori']; ?>">
Ubah
</button>

<a href="hapus.php?id=<?= $d['id_kategori']; ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Hapus kategori ini?')">
Hapus
</a>

</td>
</tr>


<!-- MODAL UBAH -->
<div class="modal fade" id="ubah<?= $d['id_kategori']; ?>">
<div class="modal-dialog">
<div class="modal-content">

<form action="ubah.php" method="POST">

<div class="modal-header">
<h5>Ubah Kategori</h5>
<button class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">
<input type="hidden" name="id" value="<?= $d['id_kategori']; ?>">

<input type="text"
name="nama"
value="<?= $d['nama_kategori']; ?>"
class="form-control"
required>
</div>

<div class="modal-footer">
<button class="btn btn-warning">Update</button>
</div>

</form>

</div>
</div>
</div>

<?php } ?>

</tbody>
</table>
</div>


<!-- MODAL TAMBAH -->
<div class="modal fade" id="tambah">
<div class="modal-dialog">
<div class="modal-content">

<form action="tambah.php" method="POST">

<div class="modal-header">
<h5>Tambah Kategori</h5>
<button class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">
<input type="text"
name="nama"
class="form-control"
placeholder="Nama kategori"
required>
</div>

<div class="modal-footer">
<button class="btn btn-primary">Simpan</button>
</div>

</form>

</div>
</div>
</div>


</div>
</main>
<script src="<?= base_url ?>bootstrap/js/bootstrap.bundle.min.js"></script>

