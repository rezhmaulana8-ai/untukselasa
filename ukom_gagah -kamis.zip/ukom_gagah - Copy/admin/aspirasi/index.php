<?php
session_start();

/* =========================
   CEK ROLE ADMIN
========================= */
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("location:../../index.php");
    exit;
}

$_SESSION['menu'] = "aspirasi";

include "../../includes/koneksi.php";
include "../../includes/navbarAdmin.php";
?>

<main class="flex-fill">
<div class="container mt-4">

<h3 class="mb-3">Manajemen Aspirasi Siswa</h3>

<div class="table-responsive">
<div class="row g-3">

<?php
$no=1;

$query = mysqli_query($koneksi,"
SELECT a.*, u.nama, k.nama_kategori
FROM tb_aspirasi a
JOIN tb_user u ON a.id_user=u.id_user
JOIN tb_kategori k ON a.id_kategori=k.id_kategori
ORDER BY 
  CASE 
    WHEN a.status = 'proses' THEN 1
    WHEN a.status = 'menunggu' THEN 2
    WHEN a.status = 'selesai' THEN 3
    WHEN a.status = 'ditolak' THEN 4
    ELSE 5
  END,
  a.created_at DESC
");

while($d = mysqli_fetch_array($query)){
?>

<div class="col-md-6 col-lg-4">
  <div class="card shadow-sm h-100">

    <!-- FOTO -->
    <?php if(!empty($d['foto'])){ ?>
  <a href="#" data-bs-toggle="modal" data-bs-target="#fotoModal<?= $d['id_aspirasi'] ?>">
    <img src="/ukom_gagah/uploads/aspirasi/<?= $d['foto'] ?>" 
         class="card-img-top"
         style="height:200px; object-fit:cover; cursor:pointer;">
  </a>

  <!-- MODAL PREVIEW FOTO -->
  <div class="modal fade" id="fotoModal<?= $d['id_aspirasi'] ?>" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content bg-dark">
        <div class="modal-body text-center p-2">
          <img src="/ukom_gagah/uploads/aspirasi/<?= $d['foto'] ?>" 
               class="img-fluid rounded">
        </div>
      </div>
    </div>
  </div>

<?php } else { ?>
  <div class="bg-light d-flex align-items-center justify-content-center" style="height:200px;">
    <span class="text-muted">Tidak ada foto</span>
  </div>
<?php } ?>


    <div class="card-body d-flex flex-column">

      <h5 class="card-title mb-1"><?= htmlspecialchars($d['nama']) ?></h5>
      <small class="text-muted"><?= $d['nama_kategori'] ?> • <?= $d['lokasi'] ?></small>

      <p class="card-text mt-2" style="flex:1;">
        <?= nl2br(htmlspecialchars($d['isi_aspirasi'])) ?>
      </p>

      <!-- STATUS -->
      <div class="mb-2">
        <form action="update_status.php" method="POST">
          <input type="hidden" name="id" value="<?= $d['id_aspirasi'] ?>">

          <select name="status" class="form-select form-select-sm"
                  onchange="this.form.submit()">

          <?php if($d['status']=="menunggu"){ ?>
              <option value="menunggu" selected>Menunggu</option>
              <option value="proses">Proses</option>

          <?php } elseif($d['status']=="proses"){ ?>
              <option value="proses" selected>Proses</option>
              <option value="selesai">Selesai</option>
              <option value="ditolak">Ditolak</option>

          <?php } elseif($d['status']=="selesai"){ ?>
              <option value="selesai" selected>Selesai</option>

          <?php } elseif($d['status']=="ditolak"){ ?>
              <option value="ditolak" selected>Ditolak</option>
          <?php } ?>

          </select>
        </form>
      </div>

      <small class="text-muted mb-2">
        <i class="bi bi-calendar"></i>
        <?= date('d-m-Y H:i', strtotime($d['created_at'])) ?>
      </small>

      <!-- ACTION -->
      <div class="d-grid gap-1">

        <?php if($d['status'] == 'proses'){ ?>
          <a href="../../siswa/feedback.php?id=<?= $d['id_aspirasi'] ?>" 
             class="btn btn-success btn-sm">
             <i class="bi bi-chat-dots"></i> Chat
          </a>
        <?php } ?>

        <?php if($d['status'] == 'menunggu'){ ?>
          <button class="btn btn-warning btn-sm" disabled>
            <i class="bi bi-clock"></i> Menunggu
          </button>
        <?php } ?>

        <?php if($d['status'] == 'selesai'){ ?>
          <button class="btn btn-primary btn-sm" disabled>
            <i class="bi bi-check-square-fill"></i> Selesai
          </button>
        <?php } ?>

        <?php if($d['status'] == 'ditolak'){ ?>
          <button class="btn btn-danger btn-sm" disabled>
            <i class="bi bi-x-circle"></i> Ditolak
          </button>
        <?php } ?>

      </div>

    </div>
  </div>
</div>

<?php } ?>

</div>

</table>
</div>

</div>
</main>
<script src="<?= base_url ?>bootstrap/js/bootstrap.bundle.min.js"></script>
<?php
include "../../includes/footer.php";
?>
