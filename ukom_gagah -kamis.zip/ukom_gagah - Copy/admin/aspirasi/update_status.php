<?php
include "../../includes/koneksi.php";

$id = $_POST['id'];
$status_baru = $_POST['status'];

// ambil status lama
$q = mysqli_query($koneksi, "SELECT status FROM tb_aspirasi WHERE id_aspirasi='$id'");
$d = mysqli_fetch_assoc($q);

$status_lama = $d['status'];

$boleh = false;

// aturan transisi
if($status_lama == 'menunggu' && $status_baru == 'proses'){
    $boleh = true;
}
elseif($status_lama == 'proses' && in_array($status_baru, ['selesai','ditolak'])){
    $boleh = true;
}

// eksekusi jika valid
if($boleh){
    mysqli_query($koneksi, "UPDATE tb_aspirasi SET status='$status_baru' WHERE id_aspirasi='$id'");
}

header("location:index.php");
?>
