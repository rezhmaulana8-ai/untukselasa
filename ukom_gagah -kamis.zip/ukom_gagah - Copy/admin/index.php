<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("location:../index.php");
    exit;
}

$_SESSION['menu'] = "beranda";

include "../includes/koneksi.php";
include "../includes/navbarAdmin.php";


/* =========================
   HITUNG TOTAL DATA
========================= */

$kelas     = mysqli_fetch_row(mysqli_query($koneksi,"SELECT COUNT(*) FROM tb_kelas"))[0];

$siswa     = mysqli_fetch_row(mysqli_query($koneksi,"
                SELECT COUNT(*) FROM tb_user WHERE role='user'
            "))[0];

$kategori  = mysqli_fetch_row(mysqli_query($koneksi,"SELECT COUNT(*) FROM tb_kategori"))[0];

$aspirasi  = mysqli_fetch_row(mysqli_query($koneksi,"SELECT COUNT(*) FROM tb_aspirasi"))[0];

?>
<main class="flex-fill">
<div class="container mt-3">
<h1 class="mb-4">Dashboard Admin</h1>
</div>
<div class="row g-3 mt-5">

    <!-- KELAS -->
    <div class="col-lg-3 col-sm-6   ">
        <div class="card shadow h-100 border-0 ">
            <div class="card-body text-center">
                <h6>Total Kelas</h6>
                <h2 class="fw-bold"><?= $kelas ?></h2>
                <a href="<?= base_url ?>admin/kelas" class="btn btn-info text-light mt-2">
                    Lihat
                </a>
            </div>
        </div>
    </div>


    <!-- SISWA -->
    <div class="col-lg-3 col-sm-6">
        <div class="card shadow h-100 border-0">
            <div class="card-body text-center">
                <h6>Total Siswa</h6>
                <h2 class="fw-bold"><?= $siswa ?></h2>
                <a href="<?= base_url ?>admin/siswa" class="btn btn-info text-light mt-2">
                    Lihat
                </a>
            </div>
        </div>
    </div>


    <!-- KATEGORI -->
    <div class="col-lg-3 col-sm-6">
        <div class="card shadow h-100 border-0">
            <div class="card-body text-center">
                <h6>Total Kategori</h6>
                <h2 class="fw-bold"><?= $kategori ?></h2>
                <a href="<?= base_url ?>admin/kategori" class="btn btn-info text-light mt-2">
                    Lihat
                </a>
            </div>
        </div>
    </div>


    <!-- ASPIRASI -->
    <div class="col-lg-3 col-sm-6">
        <div class="card shadow h-100 border-0">
            <div class="card-body text-center">
                <h6>Total Aspirasi</h6>
                <h2 class="fw-bold"><?= $aspirasi ?></h2>
                <a href="<?= base_url ?>admin/aspirasi" class="btn btn-info text-light mt-2">
                    Lihat
                </a>
            </div>
        </div>
    </div>

</div>
</main>
<?php
include "../includes/footer.php";
?>
