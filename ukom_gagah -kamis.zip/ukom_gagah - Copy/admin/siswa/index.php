<?php
session_start();

/* =========================
   CEK LOGIN ADMIN
========================= */
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("location:../../index.php");
    exit;
}

/* =========================
   MENU AKTIF
========================= */
$_SESSION['menu'] = "siswa";

include "../../includes/koneksi.php";

include "../../includes/navbarAdmin.php";
?>

<main class="flex-fill">
<div class="container mt-4">

<h2 class="mb-5">Manajemen Siswa</h2>


<!-- =========================
     TOMBOL TAMBAH
========================= -->
  <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modaltambah">
            + Tambah Siswa
        </button>

<!-- =========================
     NOTIFIKASI
========================= -->
<?php if(isset($_GET['msg'])): ?>
<div id="notif" class="alert alert-success">
    ✅ Data berhasil diproses
</div>

<script>
setTimeout(()=>{
    document.getElementById('notif').remove();
    window.history.replaceState(null,null,window.location.pathname);
},2000);
</script>
<?php endif; ?>



<!-- =========================
     TABEL SISWA
========================= -->
<div class="table-responsive">
<table class="table table-bordered table-striped">

<thead class="table-info text-center">
<tr>
    <th width="50">No</th>
    <th>Nama</th>
    <th>NIS</th>
    <th>Email</th>
    <th>Kelas</th>
    <th>jenis kelamin</th>
    <th width="170">Aksi</th>
</tr>
</thead>

<tbody>

<?php
$no = 1;

$query = mysqli_query($koneksi,"
SELECT u.*, k.nama_kelas
FROM tb_user u
LEFT JOIN tb_kelas k ON u.id_kelas = k.id_kelas
WHERE u.role='user'
ORDER BY u.nama ASC
");

while($d = mysqli_fetch_array($query)){
?>

<tr>
<td class="text-center"><?= $no++; ?></td>
<td><?= $d['nama']; ?></td>
<td><?= $d['nis']; ?></td>
<td><?= $d['email']; ?></td>
<td><?= $d['nama_kelas'] ?? '-'; ?></td>
<td><?= $d['jenis_kelamin'] ?? '-'; ?></td>

<td class="text-center">

    <!-- UBAH -->
    <button class="btn btn-warning btn-sm"
        data-bs-toggle="modal"
        data-bs-target="#ubah<?= $d['id_user']; ?>">
        Ubah
    </button>

    <!-- HAPUS -->
    <a href="hapus.php?id=<?= $d['id_user']; ?>"
       class="btn btn-danger btn-sm"
       onclick="return confirm('Yakin hapus siswa ini?')">
       Hapus
    </a>

</td>
</tr>



<!-- =========================
     MODAL UBAH
========================= -->
<div class="modal fade" id="ubah<?= $d['id_user']; ?>">
<div class="modal-dialog">
<div class="modal-content">

<form action="ubah.php" method="POST">

<div class="modal-header">
<h5 class="modal-title">Ubah Siswa</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">

<input type="hidden" name="id_user" value="<?= $d['id_user']; ?>">

<input type="text" name="nama" class="form-control mb-2"
value="<?= $d['nama']; ?>" required>

<input type="text" name="nis" class="form-control mb-2"
value="<?= $d['nis']; ?>" required>

<input type="email" name="email" class="form-control mb-2"
value="<?= $d['email']; ?>" required>

<select name="id_kelas" class="form-control mb-2" required>
<?php
$kelas = mysqli_query($koneksi,"SELECT * FROM tb_kelas");
while($k = mysqli_fetch_array($kelas)){
$sel = ($k['id_kelas']==$d['id_kelas'])?'selected':'';
echo "<option value='$k[id_kelas]' $sel>$k[nama_kelas]</option>";
}
?>
</select>

<input type="password"
name="password"
class="form-control"
placeholder="Kosongkan jika tidak ganti password">

</div>

<div class="modal-footer">
<button class="btn btn-warning">Update</button>
</div>

</form>

</div>
</div>
</div>

<?php } ?>

</tbody>
</table>
</div>



<!-- =========================
     MODAL TAMBAH
========================= -->
<div class="modal fade" id="modaltambah">
  <div class="modal-dialog">
    <div class="modal-content border border-3 border-primary">

      <form action="tambah.php" method="POST">

        <div class="modal-header">
          <h5 class="modal-title">Tambah Siswa</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">

          <input type="text" name="nama" class="form-control mb-2" placeholder="Nama" required>

          <input type="text" name="nis" class="form-control mb-2" placeholder="NIS" required>
          <div class="mb-3">
          <div class="input-group">
            <span class="input-group-text">@</span>
          <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>
          </div>
          </div>
          <!-- Jenis Kelamin -->
         <div class="form-check">
            <input type="radio" class="form-check-input" name="jenis_kelamin" id="lakilaki" value="L">
            <label for="" class="form-check-label">Laki laki</label>
         </div>
          <div class="form-check">
            <input type="radio" class="form-check-input" name="jenis_kelamin" id="perempuan" value="P">
             <label for="" class="form-check-label">Perempuan</label>
         </div>
          <!-- Kelas -->
          <select name="id_kelas" class="form-control mb-2" required>
            <option value="">-- Pilih Kelas --</option>
            <?php
            $kelas = mysqli_query($koneksi,"SELECT * FROM tb_kelas");
            while($k = mysqli_fetch_array($kelas)){
              echo "<option value='$k[id_kelas]'>$k[nama_kelas]</option>";
            }
            ?>
          </select>

          <input type="password" name="password" class="form-control" placeholder="Password" required>

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>

      </form>

    </div>
  </div>
</div>




</div>
</main>
<?php
include "../../includes/footer.php";
?>
