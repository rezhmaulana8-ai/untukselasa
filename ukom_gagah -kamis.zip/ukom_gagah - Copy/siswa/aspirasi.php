<?php
session_start();
include "../includes/koneksi.php";


if(!isset($_SESSION['id_user'])){
    header("Location: ../login/login.php");
    exit;
}


$id_user    = $_SESSION['id_user'];
$id_kategori = $_POST['id_kategori'];
$lokasi     = $_POST['lokasi'];
$isi        = $_POST['isi_aspirasi'];
$foto_name = null;

if(isset($_FILES['foto']) && $_FILES['foto']['error'] == 0){

    $tmp  = $_FILES['foto']['tmp_name'];
    $name = $_FILES['foto']['name'];
    $size = $_FILES['foto']['size'];

    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $allowed = ['jpg','jpeg','png'];

    if(!in_array($ext, $allowed)){
        echo "Format foto tidak valid!";
        exit;
    }

    if($size > 2 * 1024 * 1024){
        echo "Ukuran foto maksimal 2MB!";
        exit;
    }

    $newName = time().'_'.uniqid().'.'.$ext;
    $uploadPath = "../uploads/aspirasi/".$newName;

    if(move_uploaded_file($tmp, $uploadPath)){
        $foto_name = $newName;
    } else {
        echo "Upload foto gagal!";
        exit;
    }
}


if($id_kategori == "" || $lokasi == "" || $isi == ""){
    echo "<script>
        alert('Semua field wajib diisi!');
        window.history.back();
    </script>";
    exit;
}


$query = mysqli_query($koneksi, "
    INSERT INTO tb_aspirasi
    (id_user, id_kategori, lokasi, isi_aspirasi, foto, status, created_at, updated_at)
    VALUES
    ('$id_user', '$id_kategori', '$lokasi', '$isi', '$foto_name', 'menunggu', NOW(), NOW())
");



if($query){
    echo "<script>
        alert('Aspirasi berhasil dikirim!');
        window.location.href='index.php';
    </script>";
}else{
    echo "<script>
        alert('Gagal mengirim aspirasi!');
        window.history.back();
    </script>";
}
?>
