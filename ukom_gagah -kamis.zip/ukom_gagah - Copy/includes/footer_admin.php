   <!-- ================= FOOTER ================= -->
<!-- ================= FOOTER FULL WIDTH ================= -->
 
    <!-- akir footer  -->
<script src="<?= base_url."bootstrap/js/bootstrap.bundle.js"; ?>"></script>
</body>
</html>




<script src="<?= base_url ?>bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
