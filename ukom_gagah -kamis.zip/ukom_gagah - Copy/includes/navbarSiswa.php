 <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow fixed-top">
  <div class="container">
    
    <!-- Brand -->
    <a href="../siswa/" class="navbar-brand fw-bold">Aduin</a>

    <!-- Toggle Button (Hamburger) -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAduin">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Menu -->
    <div class="collapse navbar-collapse" id="navbarAduin">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-2">



       
      <li class="nav-item">
        <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#logoutModal">
          Keluar
        </button>
      </li>

   


      </ul>
    </div>
  </div>
</nav>
  <div class="modal fade" id="logoutModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Konfirmasi Logout</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        Yakin mau keluar dari akun?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <a href="../login/logout.php" class="btn btn-danger">Keluar</a>
      </div>
    </div>
  </div>
</div>