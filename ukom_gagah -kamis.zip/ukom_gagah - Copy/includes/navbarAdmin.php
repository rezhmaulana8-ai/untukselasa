<?php include "baseurl.php"; ?>

<link rel="stylesheet" href="<?= base_url ?>bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?= base_url ?>bootstrap-icons/bootstrap-icons.css">

<body class="d-flex flex-column min-vh-100">
    <!-- awal navbar -->
    <nav class="navbar bg-primary navbar-expand-lg bg-body-primary  shadow" data-bs-theme="dark">
        <div class="container">
                <a href="<?=  base_url."admin"?>" class="navbar-brand fw-bold">Aduin</a>
                <div class="collapse navbar-collapse">
                    <ul class="navbar-nav me-auto">
                          <li class="nav-item"><a href="<?= base_url."admin/";?>" class="nav-link <?php if($_SESSION['menu']=="beranda") {echo "active fw-bold text-light";}?>">Beranda</a></li>
                        <li class="nav-item"><a href="<?= base_url."admin/kelas";?>" class="nav-link <?php if($_SESSION['menu']=="kelas") {echo "active fw-bold text-light";}?>">Kelas</a></li>
                        <li class="nav-item"><a href="<?= base_url."admin/siswa";?>" class="nav-link <?php if($_SESSION['menu']=="siswa") {echo "active fw-bold text-light";}?>">Siswa</a></li>
                        <li class="nav-item"><a href="<?= base_url."admin/kategori";?>" class="nav-link <?php if($_SESSION['menu']=="kategori") {echo "active fw-bold text-light";}?>">Kategori</a></li>
                        <li class="nav-item"><a href="<?= base_url."admin/aspirasi";?>" class="nav-link <?php if($_SESSION['menu']=="aspirasi") {echo "active fw-bold text-light";}?>">Aspirasi</a></li>
                       
                    </ul>
                    
                  <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a href="<?= base_url ?>login/logout.php" class="btn btn-danger">Keluar</a></li>
                  </ul>
                </div>
        </div>
    </nav>
    <!-- akhir navbar -->